# Projects & Tasks

- [Projects](Projects%20&%20Tasks%20104d4deadd2c805fb3abcaab6d3727e7/Projects%2058b8977d6e4444a98ec4d64176a071e5.md): This is your overview of all the projects in the pipeline
- [Tasks](Projects%20&%20Tasks%20104d4deadd2c805fb3abcaab6d3727e7/Tasks%2076aaf8a4637542ed8175259692ca08bb.md)**:** This is your detailed breakdown of every task under your projects

[Tasks](Projects%20&%20Tasks%20104d4deadd2c805fb3abcaab6d3727e7/Tasks%2076aaf8a4637542ed8175259692ca08bb.csv)

↓ Click through the different database tabs to see the same data in different ways

Hover over any project name and click `◨ OPEN` to view more info and its associated tasks

[Projects](Projects%20&%20Tasks%20104d4deadd2c805fb3abcaab6d3727e7/Projects%2058b8977d6e4444a98ec4d64176a071e5.csv)