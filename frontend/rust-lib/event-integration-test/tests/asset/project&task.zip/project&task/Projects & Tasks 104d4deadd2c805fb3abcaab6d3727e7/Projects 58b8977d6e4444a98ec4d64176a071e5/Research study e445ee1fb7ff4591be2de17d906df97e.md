# Research study

Status: In Progress
Owner: Nate Martins
Completion: 0.25
Dates: April 23, 2024 → May 22, 2024
Checkbox: No
Delay: 7
Files & media: ../DO010003572.jpeg
Is Blocking: Marketing campaign (Marketing%20campaign%2088ac0cea4cb245efb44d63ace0a37d1e.md)
Priority: High
Summary: A research study is underway to understand customer satisfaction and identify improvement areas. The team is developing a survey to gather data from customers, aiming to analyze insights for strategic decision-making and enhance satisfaction.
Tasks: Develop survey questions (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Develop%20survey%20questions%2086ce25c6bb214b4b9e35beed8bc8b821.md), Interpret findings (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Interpret%20findings%20c418ae6385f94dcdadca1423ad60146b.md), Write research report (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Write%20research%20report%20cca8f4321cd44dceba9c266cdf544f15.md), Conduct interviews (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Conduct%20interviews%208f40c17883904d769fee19baeb0d46a5.md)

## About this project

The research study was initiated to gain a deeper understanding of customer satisfaction and identify areas for improvement. Feedback from customers indicated that there were some areas of our product and service that could be improved to better meet their needs. 

The research team is developing a survey to collect data from a representative sample of customers, which will be analyzed to identify patterns and insights. The goal of the project is to use the findings to inform strategic decision-making and improve customer satisfaction.

## User interviews

[https://www.notion.so](https://www.notion.so)

[https://www.notion.so](https://www.notion.so)

## Project tasks

[Tasks](Research%20study%20e445ee1fb7ff4591be2de17d906df97e/Tasks%206532f12bac0d4390a8e6b2f7fc0eff5e.csv)