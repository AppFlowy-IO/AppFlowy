# Website redesign

Status: Planning
Owner: Nate Martins
Dates: May 10, 2024 → May 26, 2024
Blocked By: Marketing campaign (Marketing%20campaign%2088ac0cea4cb245efb44d63ace0a37d1e.md)
Checkbox: Yes
Priority: Medium
Summary: The website redesign project, led by Nate Martins from May 10 to May 26, 2024, aims to create a more effective onboarding process to enhance user experience and increase 7-day retention by 25%.
Tasks: Conduct website audit (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Conduct%20website%20audit%20aee812f0c962462e8b91e8044a268eb5.md), Write website copy (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Write%20website%20copy%209ab9309ceae34f6f8dc19b2eeda8f8f2.md), Test website functionality (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Test%20website%20functionality%208ccf7153028747b19a351f6d36100f0d.md), Develop creative assets (../Tasks%2076aaf8a4637542ed8175259692ca08bb/Develop%20creative%20assets%206fe86230e30843ebb60c67724f0f922f.md)

## About this project

Because our app has so many features, and serves so many personas and use cases, many users find the current onboarding process overwhelming, and don’t experience their “a ha” moment quickly enough.

This quarter, the user education team is investing in a holistically redesigned onboarding flow, with a goal of increasing 7 day retention by 25%.

## Proposed user journey

## Project tasks

[Tasks](Website%20redesign%20bb934cb9f0e44daab4368247d62b0f39/Tasks%2053e1d6f3ea284d77bf007215c17e179a.csv)