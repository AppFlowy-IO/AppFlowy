# Create performance marketing plan

Assignee: Nate Martins
Status: Not Started
Due: May 2, 2023
Project: Marketing campaign (../Projects%2058b8977d6e4444a98ec4d64176a071e5/Marketing%20campaign%2088ac0cea4cb245efb44d63ace0a37d1e.md)
Parent-task: Develop advertising plan (Develop%20advertising%20plan%20a8e534ad763040029d0feb27fdb1820d.md)
Priority: Medium
Tags: Improvement, Marketing