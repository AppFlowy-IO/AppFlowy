# Develop advertising plan

Assignee: Nate Martins
Status: Done
Due: April 13, 2024
Project: Marketing campaign (../Projects%2058b8977d6e4444a98ec4d64176a071e5/Marketing%20campaign%2088ac0cea4cb245efb44d63ace0a37d1e.md)
Sub-tasks: Create social media plan (Create%20social%20media%20plan%204e70ea0b7d40427a9648bcf554a121f6.md), Create performance marketing plan (Create%20performance%20marketing%20plan%20b6aa6a9e9cc1446490984eaecc4930c7.md)
Priority: Medium
Tags: Improvement, Marketing
Completed on: April 16, 2024
Delay: 3